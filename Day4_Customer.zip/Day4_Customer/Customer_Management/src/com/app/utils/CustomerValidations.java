package com.app.utils;

//1. Sign up (customer registration)
//Accept customer details
//Validate all inputs.
//In case of successful validations , 
//add customer details in the D.S , 
//display customer details via toString or display error mesg via custom exception.


public class CustomerValidations {
	public static Customermngmt validateinputs() 
}
