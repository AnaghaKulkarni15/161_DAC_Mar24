package com.app.Custom_Exception;

@SuppressWarnings("serial")
public class CustomerException extends Exception{
	public CustomerException(String msg) {
		super(msg);
	}
	
}
