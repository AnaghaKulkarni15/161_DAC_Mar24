package com.app.tester;

import java.time.LocalDate;
import java.util.Scanner;

import com.app.customer.CustomerMngmt;
import com.app.customer.ServicePlan;

public class CustomerApp {

	public static void main(String[] args) {
		try(Scanner in = new Scanner(System.in)){
			Boolean exit = false;
			System.out.println("Enter Maximum no. of customer Accounts");
			CustomerMngmt[] accounts  = new CustomerMngmt[in.nextInt()];
			int counter = 0;
			while(!exit) {
				System.out.println("--Main Menu--");
				System.out.println("\n1.Create Customer Accounts \n 2. Display Customer Accounts \n 0.Exit");
				System.out.println("Choose an Option:");
				try {
					switch(in.nextInt()) {
					case 1 :
						if(counter < accounts.length) {
							System.out.println("custid,fname,lname,passwd,regiamt,dob,plan");
							//System.out.println(in.nextInt(),in.next(),in.next(),in.next(),in.next(),in.next(),plan);
							//accounts[counter++] = acct;
							System.out.println("Account created !");

						}
						break;
					
					case 2:
						
						break;
					}
				}
				catch(Exception e) {
					System.out.println(e);
					in.nextLine();
				}
				
				
			}
		}

	}

}
