package com.app.customer;

import java.time.LocalDate;

//Customer should be assigned system generated (auto increment) customer id : int
//Store - first name, last name email(string),password(string),registrationAmount(double),dob(LocalDate),plan(ServicePlan : enum)
//Unique ID - email (2 customers CAN NOT have SAME email id)


public class CustomerMngmt {
	protected int custid;
	protected String fname;
	protected String lname;
	protected String passwd;
	protected double regiamt;
	protected LocalDate dob;
	private ServicePlan plan;
	
	public CustomerMngmt(int custid, String fname,String lname,String passwd,
			double regiamt,LocalDate dob,ServicePlan plan)
	{
		super();
		this.custid =custid;
		this.fname = fname;
		this.lname = lname;
		this.passwd = passwd;
		this.regiamt= regiamt;
		this.dob = dob;
		this.plan = plan;	
		
	}

	@Override
	public String toString() {
		return "CustomerMngmt [custid=" + custid + ", fname=" + fname + ", lname=" + lname + ", passwd=" + passwd
				+ ", regiamt=" + regiamt + ", dob=" + dob + ", plan=" + plan + "]";
	}
	
	
	
	
	
	
}
